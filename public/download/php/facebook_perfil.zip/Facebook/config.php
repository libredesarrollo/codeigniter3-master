<?php
//Facebook configuration
$config['App_ID']      =   'Mi_App_ID';
$config['App_Secret']  =   'Mi_App_Secret'; 
<?php
//Facebook configuration
$config['App_ID']      =   'Tu_App_ID';
$config['App_Secret']  =   'Tu_App_Secret'; 